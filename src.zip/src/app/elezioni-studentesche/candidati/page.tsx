import styles from "./page.module.css";
import Link from "next/link";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "I nostri candidati | Elezioni Studentesche",
  description: "Scopri tutti i candidati di Gulliver per le elezioni studentesche UNIVPM 2025.",
};

const DATA = [
  {
    "organ": "CONSIGLIO STUDENTESCO",
    "sub_organ": null,
    "type": "Ordinari",
    "count": "30",
    "candidates": [
      "Luigino Ripa detto Luigi",
      "Mattia Taliani detto tali",
      "Chiara Carlomagno",
      "Damiano Pelino",
      "Serena Fiorentino detta Agraria",
      "Fernando Pierluigi Cordova Villanueva detto Nando",
      "Federico Forte detto Fermo",
      "Alessandro Pardi detto Gatto",
      "Veronica Barlassina detta Veromed",
      "Aurora Moretti detta Aurò",
      "Andrea Belardinelli detto Dottorando",
      "Xavier Paulo lacovella",
      "Giuseppe Tordela detto Tordo",
      "Sagida Cherqaoui detta Sagi detta Bartolo",
      "Sabrina Bocci detta Asbri detta DEB",
      "Riccardo Piccinini",
      "Daniele Minnetti detto Infermieristica",
      "Lorenzo Califano",
      "Alessandro Cerquetti",
      "Rosa Alba Cappucci",
      "Viola Medici",
      "Daniele Raiola",
      "Giulio Zola",
      "Celeste Maiorani",
      "Matteo Mancinelli",
      "Lorenzo Carpinteri",
      "Luca Farinelli",
      "Rebecca Ferrara",
      "Pier Francesco Capretta",
      "Pierpaolo Cetroni"
    ],
    "is_cs": true
  },
  {
    "organ": "DIPARTIMENTI DELLA FACOLTA' DI INGEGNERIA",
    "sub_organ": null,
    "type": "Ordinari",
    "count": "41",
    "candidates": [
      "Chiara Carlomagno (Pref: DII)",
      "Pier Francesco Capretta (Pref: DII)",
      "Jacopo Catini (Pref: DIISM)",
      "Pierpaolo Cetroni (Pref: DICEA)",
      "Lorenzo Califano (Pref: DIISM)",
      "Alessandro Pardi detto Gatto (Pref: DII)",
      "Sagida Cherqaoui (Pref: DICEA)",
      "Lorenzo Carpinteri (Pref: SIMAU)",
      "Federico Forte (Pref: DIISM)",
      "Celeste Maiorani (Pref: DII)",
      "Sara D'Orfeo (Pref: DIISM)",
      "Veronica Carretta (Pref: DICEA)",
      "Davide Marini (Pref: SIMAU)",
      "Gianluca Di Nicola (Pref: DIISM)",
      "Daniele Raiola (Pref: DII)",
      "Alfonso Antonio Capria (Pref: DII)",
      "Nicolas Passeri (Pref: DII)",
      "Marco Silenzi (Pref: SIMAU)",
      "Emanuel Hoxha (Pref: SIMAU)",
      "Edoardo Orselli detto Manto Bianco (Pref: DII)",
      "Aureliano Ortelli (Pref: DIISM)",
      "Tommaso Pasqualetti detto dajeroma14 (Pref: SIMAU)",
      "Pasquale Edward David Liconti (Pref: DII)",
      "Marco Massacesi detto Ivo (Pref: DICEA)",
      "Penelope Bezi (Pref: DICEA)",
      "Sokeng Arol Mendel (Pref: DII)",
      "Ivan Migliore detto divanetto (Pref: DIISM)",
      "Amedea Di Santo (Pref: DII)",
      "Martina Travaglini (Pref: DICEA)",
      "Vittorio Emanuele Raciti (Pref: DIISM)",
      "Martina Lonzi (Pref: DICEA)",
      "Luca Ghironzi (Pref: DII)",
      "Maksym Kachanov (Pref: DII)",
      "Liberato Ciervo (Pref: DII)",
      "Rebecca Vittorini (Pref: DIISM)",
      "Rami Ben Ahmed (Pref: DII)",
      "Michele Di Rodi (Pref: DICEA)",
      "Luigi di Bartolomeo (Pref: DICEA)",
      "Sofia Masotina (Pref: DICEA)",
      "Marco Mattucci (Pref: DIISM)",
      "Ivan Crivohija (Pref: DII)"
    ],
    "is_cs": false
  },
  {
    "organ": "DIPARTIMENTI DELLA FACOLTA' DI INGEGNERIA",
    "sub_organ": null,
    "type": "LISTA DOTTORANDI",
    "count": "7",
    "candidates": [
      "Guerino Gianfranco Paolini (Pref: DII)",
      "Sara Meletani (Pref: DIISM)",
      "Meri Gjika (Pref: DII)",
      "Giorgio Mattioli (Pref: SIMAU)",
      "Federico Giulioni (Pref: DICEA)",
      "Anna Maria Schiavone (Pref: SIMAU)",
      "Ludovica Marcelli (Pref: DICEA)"
    ],
    "is_cs": false
  },
  {
    "organ": "DIPARTIMENTO DI SCIENZE AGRARIE, ALIMENTARI E AMBIENTALI",
    "sub_organ": null,
    "type": "Ordinari",
    "count": "6",
    "candidates": [
      "Riccardo Piccinini (Pref: D3A)",
      "Serena Fiorentino (Pref: D3A)",
      "Alessio Cantarini (Pref: D3A)",
      "Maurizia Sii Onesto (Pref: D3A)",
      "Alessio Alfonsi (Pref: D3A)",
      "Loris Seghetti (Pref: D3A)"
    ],
    "is_cs": false
  },
  {
    "organ": "DIPARTIMENTO DI SCIENZE AGRARIE, ALIMENTARI E AMBIENTALI",
    "sub_organ": null,
    "type": "LISTA DOTTORANDI",
    "count": "1",
    "candidates": [
      "Ashim Aizhan (Pref: D3A)"
    ],
    "is_cs": false
  },
  {
    "organ": "DIPARTIMENTO DI SCIENZE DELLA VITA E DELL'AMBIENTE",
    "sub_organ": null,
    "type": "Ordinari",
    "count": "11",
    "candidates": [
      "Damiano Pelino (Pref: DISVA)",
      "Asja Di Donato (Pref: DISVA)",
      "Xavier Paulo lacovella (Pref: DISVA)",
      "Rosa Alba Cappucci (Pref: DISVA)",
      "Giacomo Santini (Pref: DISVA)",
      "Julia Themis Valenzuela Carbajal (Pref: DISVA)",
      "Mara Caniglia (Pref: DISVA)",
      "Nicole Cadoria (Pref: DISVA)",
      "Hichem Bahaeddine Yagoubi (Pref: DISVA)",
      "Federica Di Marzo (Pref: DISVA)",
      "Marzia Miriam Gasparini (Pref: DISVA)"
    ],
    "is_cs": false
  },
  {
    "organ": "DIPARTIMENTO DI SCIENZE DELLA VITA E DELL'AMBIENTE",
    "sub_organ": null,
    "type": "LISTA DOTTORANDI",
    "count": "1",
    "candidates": [
      "Chiara Spinsante (Pref: DISVA)"
    ],
    "is_cs": false
  },
  {
    "organ": "DIPARTIMENTI DELLA FACOLTA' DI ECONOMIA \"GIORGIO FUA\"",
    "sub_organ": null,
    "type": "Ordinari",
    "count": "31",
    "candidates": [
      "Aurora Moretti detta Aurò (Pref: DISES)",
      "Mattia Taliani detto tali (Pref: DIMA)",
      "Alessandro Cerquetti (Pref: DIMA)",
      "Luca Farinelli (Pref: DISES)",
      "Sabrina Bocci detta Asbri (Pref: DIMA)",
      "Davide Ciarcelluti (Pref: DIMA)",
      "lana Bors (Pref: DIMA)",
      "Sabrina Brizzola detta Sabrizzola (Pref: DIMA)",
      "Ines Chihi (Pref: DISES)",
      "Federico Navone detto II Biondino (Pref: DISES)",
      "Enea Pierini (Pref: DIMA)",
      "Federico Cannizzo Daniele (Pref: DISES)",
      "Franco Maria Piccirillo Rotili (Pref: DIMA)",
      "Allegra Morico (Pref: DIMA)",
      "Sara Santinelli (Pref: DIMA)",
      "Abdrahamane Koina (Pref: DISES)",
      "Harry Idiaghe Osazee (Pref: DIMA)",
      "Ramos Paucar Julio Armando (Pref: DIMA)",
      "Emelyn Llantoy Montalvo (Pref: DISES)",
      "Mehdi Serhane (Pref: DISES)",
      "Ludovica Bianchi detta Ludo (Pref: DIMA)",
      "Aya Mimouni (Pref: DIMA)",
      "Alice Burattini (Pref: DIMA)",
      "Esete Kebede Gebregiorgis (Pref: DISES)",
      "Bishal Kumar XXX detto Yosh (Pref: DISES)",
      "Duncan Kioko Kivindyo (Pref: DISES)",
      "Ben Nouba Nacef (Pref: DISES)",
      "Dagmawi Aschalew Belachew (Pref: DIMA)",
      "Chamoli Avni (Pref: DIMA)",
      "Sagar Patil Somnath (Pref: DISES)",
      "Mirco Rocchegiani (Pref: DISES)"
    ],
    "is_cs": false
  },
  {
    "organ": "DIPARTIMENTI DELLA FACOLTA' DI ECONOMIA \"GIORGIO FUA\"",
    "sub_organ": null,
    "type": "LISTA DOTTORANDI",
    "count": "3",
    "candidates": [
      "Andrea Belardinelli (Pref: DIMA)",
      "Alex Ricci (Pref: DIMA)",
      "Gaetano lervolino (Pref: DISES)"
    ],
    "is_cs": false
  },
  {
    "organ": "DIPARTIMENTI DELLA FACOLTA' DI MEDICINA E CHIRURGIA",
    "sub_organ": null,
    "type": "Ordinari",
    "count": "47",
    "candidates": [
      "Luigino Ripa detto Luigi (Pref: DISBSP)",
      "Fernando Pierluigi Cordova Villanueva detto Nando (Pref: DISCLIMO)",
      "Daniele Minnetti (Pref: DISCO)",
      "Sofia Maria Elena Sola detta Sofia (Pref: DISBSP)",
      "Chiara Morganti (Pref: DISBSP)",
      "Giuseppe Tordela detto Tordo (Pref: DIMSC)",
      "Laura Hyka (Pref: DISCLIMO)",
      "Giorgia Vitali (Pref: DIMSC)",
      "Giulio Zola (Pref: DISCLIMO)",
      "Alessandro Salvagno (Pref: DISCO)",
      "Viola Medici (Pref: DIMSC)",
      "Felicia Casarin (Pref: DISCLIMO)",
      "Matteo Mancinelli (Pref: DISBSP)",
      "Greta Marconi (Pref: DISCO)",
      "Aurora De Petris (Pref: DIMSC)",
      "Lisa Azzano (Pref: DISCLIMO)",
      "Giulia Brunetti (Pref: DISCLIMO)",
      "Daniel Parente (Pref: DISCLIMO)",
      "Rebecca Ferrara (Pref: DIMSC)",
      "Edoardo Maria Leoni (Pref: DISCLIMO)",
      "Benedetta Migliozzi detta Bennimi (Pref: DISBSP)",
      "Jennifer Margarete Theresia Matienzo Baldeon (Pref: DISCO)",
      "Emanuele Palazzo (Pref: DISCO)",
      "Stefan Orizarov (Pref: DISCO)",
      "Elisa Yang (Pref: DISCLIMO)",
      "Silvia Bastianelli (Pref: DIMSC)",
      "Mayar Bezzai (Pref: DISBSP)",
      "Francesco Weng detto 鑫源 (Pref: DISCO)",
      "Nicola Monacchi (Pref: DIMSC)",
      "Ipek Demiryurek (Pref: DISCO)",
      "Eftychia Leonidou (Pref: DISBSP)",
      "Francielle Kauane Da Silva Da Fonseca (Pref: DISCO)",
      "Gregoria Christofi (Pref: DISCLIMO)",
      "Rayen Razgui (Pref: DISBSP)",
      "Fabrizio Scarpini (Pref: DISCLIMO)",
      "Haad Irfan (Pref: DIMSC)",
      "Kaur Jaskeert XXX (Pref: DISCO)",
      "Sofia Paola Motterle (Pref: DISCO)",
      "Mehmet Meric Horoz (Pref: DISCO)",
      "Tommaso Scalella (Pref: DISBSP)",
      "Aakash Solomon Malik (Pref: DISCO)",
      "Elifnaz Genc (Pref: DISBSP)",
      "Advait Nair (Pref: DIMSC)",
      "Jay Pinkal Jogi (Pref: DISCLIMO)",
      "Kamal Rajkumar Singh (Pref: DISCLIMO)",
      "Alena Baldoni (Pref: DISBSP)",
      "Veronica Barlassina (Pref: DISCO)"
    ],
    "is_cs": false
  },
  {
    "organ": "DIPARTIMENTI DELLA FACOLTA' DI MEDICINA E CHIRURGIA",
    "sub_organ": null,
    "type": "LISTA DOTTORANDI",
    "count": "4",
    "candidates": [
      "Olga Strogovets (Pref: DISCLIMO)",
      "Francesco Tavoletta (Pref: DISCO)",
      "Alida Likey (Pref: DISBSP)",
      "Omayema Taoussi (Pref: DIMSC)"
    ],
    "is_cs": false
  },
  {
    "organ": "DIPARTIMENTI DELLA FACOLTA' DI MEDICINA E CHIRURGIA",
    "sub_organ": null,
    "type": "LISTA SPECIALIZZANDI",
    "count": "3",
    "candidates": [
      "Gianpaolo Casci (Pref: DIMSC)",
      "Mauro Fabrizio Acerbis (Pref: DISBSP)",
      "Chiara Giordani (Pref: DISCLIMO)"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.U.C.S. INGEGNERIA ELETTRONICA",
    "type": "Ordinari",
    "count": "8",
    "candidates": [
      "Valentino Tiberio",
      "Filomena Raspone",
      "Davide Marini",
      "Sara D'Orfeo",
      "Agustin Zottola",
      "Marco Silenzi",
      "Lorenzo Postacchini",
      "Arol Mendel Sokeng"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.U.C.S. INGEGNERIA CIVILE E AMBIENTALE",
    "type": "Ordinari",
    "count": "4",
    "candidates": [
      "Nicolò Cognini",
      "Marco Violante",
      "James Ruiz Kleidizh",
      "Michele Di Rodi"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.U.C.S. INGEGNERIA EDILE",
    "type": "Ordinari",
    "count": "1",
    "candidates": [
      "Marco Massaccesi detto Ivo"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.U.C.S. INGEGNERIA INFORMATICA E DELL'AUTOMAZIONE",
    "type": "Ordinari",
    "count": "21",
    "candidates": [
      "Chiara Carlomagno",
      "Lorenzo Califano detto Calif",
      "Celeste Maiorani",
      "Lorenzo Carpinteri",
      "Pier Francesco Capretta",
      "Ivan Migliore detto divanetto",
      "Alessandro Pardi detto Gatto",
      "Emanuel Hoxha detto Ema",
      "Greta Puzone",
      "Alfonso Antonio Capria",
      "Tommaso Pasqualetti detto dajeroma14",
      "Pasquale Edward David Liconti",
      "Amedea Di Santo",
      "Davide Ciervo",
      "Rami Ben Ahmed",
      "Jasmine De Carolis",
      "Luca Ghironzi",
      "Nicolas Passeri",
      "Vittorio Emanuele Raciti",
      "Marco Mattucci",
      "Ivan Crivohija"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.U.C.S. INGEGNERIA EDILE - ARCHITETTURA",
    "type": "Ordinari",
    "count": "6",
    "candidates": [
      "Pierpaolo Cetroni",
      "Sagida Cherqaoui detta Sagi",
      "Penelope Bezi",
      "Martina Lonzi",
      "Sofia Masotina",
      "Martina Travaglini"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.U.C.S. INGEGNERIA BIOMEDICA",
    "type": "Ordinari",
    "count": "12",
    "candidates": [
      "Thomas Bufalini",
      "Elio Kastrati",
      "Daniele Raiola",
      "Diego Reda",
      "Edoardo Orselli detto Manto Bianco",
      "Maksym Kachanov",
      "Liberato Ciervo",
      "Amal Ajedioui",
      "Emily Kate Paliferi",
      "Demeke Gebresillasse Kumlachew detto George",
      "Ali Nihad Abu Rmeileh",
      "Giorgia Perrotti"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.U.C.S. INGEGNERIA MECCANICA",
    "type": "Ordinari",
    "count": "12",
    "candidates": [
      "Rebecca Vittorini detta Puce",
      "Umberto D'Aurelio detto Pasti",
      "Gianluca Di Nicola detto Ccino",
      "Estelle Ledauphin detta Stella",
      "Luca De Dominicis",
      "Ludovica Capitanio",
      "Nicolò Bresciani",
      "Alessandro Boccanera",
      "Antonio Lo Scocco",
      "Christian Edorh",
      "Luigi Di Bartolomeo",
      "Michele Santecchia"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.U.C.S. INGEGNERIA GESTIONALE - FERMO",
    "type": "Ordinari",
    "count": "4",
    "candidates": [
      "Aureliano Ortelli",
      "Federico Forte",
      "Jacopo Catini",
      "Matteo Catini"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.U.C.S. TECNICHE DELLA COSTRUZIONE E GESTIONE DEL TERRITORIO",
    "type": "Ordinari",
    "count": "2",
    "candidates": [
      "Riccardo Cecchettini",
      "Laurence Koka"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.U.C.S. INGEGNERIA INDUSTRIALE SOSTENIBILE - PESARO",
    "type": "Ordinari",
    "count": "3",
    "candidates": [
      "Maria Pierella",
      "Massimo Malavolta",
      "Alessandro Marucci"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.U.C.S. SCIENZE E TECNOLOGIE AGRARIE E SCIENZE AGRARIE E DEL TERRITORIO",
    "type": "Ordinari",
    "count": "2",
    "candidates": [
      "Riccardo Piccinini",
      "Alessio Alfonsi"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.U.C.S. SCIENZE FORESTALI E AMBIENTALI E SCIENZE TECNOLOGIE FORESTALI E AMBIENTALI",
    "type": "Ordinari",
    "count": "2",
    "candidates": [
      "Alessio Cantarini",
      "Riccardo Manchisi"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.U.C.S. SCIENZE E TECNOLOGIE ALIMENTARI E FOOD AND BEVERAGE INNOVATION AND MANAGEMENT",
    "type": "Ordinari",
    "count": "1",
    "candidates": [
      "Serena Fiorentino (Matricola S1132183)"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. SISTEMI AGRICOLI INNOVATIVI",
    "type": "Ordinari",
    "count": "4",
    "candidates": [
      "Maurizia Sii Onesto",
      "Loris Seghetti",
      "Andrea Ripani",
      "Alessandra Calcagni"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. SCIENZE BIOLOGICHE",
    "type": "Ordinari",
    "count": "12",
    "candidates": [
      "Damiano Pelino",
      "Asja Di Donato",
      "Alessandro Silvestro Susini",
      "Xavier Paulo lacovella",
      "Rosa Alba Cappucci",
      "Mara Caniglia",
      "Julia Themis Valenzuela Carbajal",
      "Enrica Di Giovanni",
      "Emanuele Cadavero",
      "Stefano Ferrari",
      "Noemi Isnenghi",
      "Clara Rignanese"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.U.C.S ENVIRONMENTAL SCIENCE AND CIVIL PROTECTION E ENVIRONMENTAL HAZARD AND DISASTER RISK MANAGEMENT",
    "type": "Ordinari",
    "count": "4",
    "candidates": [
      "Edoardo Coppola",
      "Luca Perrone",
      "Giacomo Santini",
      "Hichem Bahaeddine Yagoubi"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. BIOLOGIA MOLECOLARE E APPLICATA",
    "type": "Ordinari",
    "count": "1",
    "candidates": [
      "Nicole Cadoria"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. MARINE BIOLOGY",
    "type": "Ordinari",
    "count": "3",
    "candidates": [
      "Marzia Miriam Gasparini",
      "Federica Di Marzo",
      "Wathsala Vidura Arachchige Kalu"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. ECONOMIA E COMMERCIO",
    "type": "Ordinari",
    "count": "18",
    "candidates": [
      "Aurora Moretti detta Aurò",
      "Mattia Taliani detto tali",
      "Alessandro Cerquetti",
      "lana Bors",
      "Enea Pierini",
      "Ludovica Bianchi",
      "Allegra Morico",
      "Federico Daniele Cannizzo",
      "Franco Maria Piccirillo Rotili",
      "Alice Burattini",
      "Angelica Vincenti",
      "Giulia Marini",
      "Samanta Selmani",
      "Erika Francesca Marseguerra",
      "Federico Ruffini detto Feffo",
      "Julio Armando Ramos Paucar",
      "Harry Osazee Idiaghe",
      "Mohamed Qochih"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. ECONOMIA E MANAGEMENT",
    "type": "Ordinari",
    "count": "4",
    "candidates": [
      "Federico Trevisani",
      "Sara Santinelli",
      "Marian Razvan Gradinaru",
      "Alessandro Nicolini"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. INTERNATIONAL ECONOMICS AND COMMERCE",
    "type": "Ordinari",
    "count": "3",
    "candidates": [
      "Duncan Kioko Kivindyo",
      "Ghada Al Hassan",
      "Mirco Rocchegiani"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. SCIENZE ECONOMICHE E FINANZIARIE",
    "type": "Ordinari",
    "count": "4",
    "candidates": [
      "Lorenzo Tarsetti detto Tars",
      "Gianmarco Biancucci",
      "Filippo Lupo Palmizi detto Lupo",
      "Fabio Fedrigucci"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. MANAGEMENT PUBBLICO E DEI SISTEMI SOCIO-SANITARI - SBT",
    "type": "Ordinari",
    "count": "1",
    "candidates": [
      "Ludovica Silvetti"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. DIGITAL ECONOMICS AND BUSINESS",
    "type": "Ordinari",
    "count": "12",
    "candidates": [
      "Luca Farinelli",
      "Sabrina Bocci detta Asbri",
      "Davide Ciarcelluti",
      "Ines Chihi",
      "Federico Navone detto Il Biondino",
      "Debora Di Benedetto",
      "Mehdi Serhane",
      "Emelyn Llantoy Montalvo",
      "Abdrahamane Koina",
      "Antonios Boulos",
      "Sagar Patil Somnath",
      "Avni Chamoli"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. MEDICINA E CHIRURGIA",
    "type": "Ordinari",
    "count": "27",
    "candidates": [
      "Luigino Ripa detto Luigi",
      "Giuseppe Tordela detto Tordo",
      "Sofia Maria Elena Sola detta Sofia",
      "Laura Hyka",
      "Alessandro Salvagno",
      "Giulio Zola",
      "Aurora De Petris",
      "Viola Medici",
      "Matteo Mancinelli",
      "Jolanda Gioia Serena Vermeulen",
      "Giorgia Vitali",
      "Benedetta Migliozzi detta Bennimi",
      "Nicola Monacchi",
      "Rebecca Ferrara",
      "Giulia Brunetti",
      "Silvia Bastianelli",
      "Felicia Casarin",
      "Francesco Weng detto 鑫源",
      "Lisa Azzano",
      "Stefan Orizarov",
      "Tommaso Scalella",
      "Alena Baldoni",
      "Rayen Razgui",
      "Emanuele Palazzo",
      "Haad Irfan",
      "Fabrizio Scarpini",
      "Sofia Paola Motterle"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. ODONTOIATRIA E PROTESI DENTARIA",
    "type": "Ordinari",
    "count": "4",
    "candidates": [
      "Moaad Khaoudi",
      "Vittoria Ferretti",
      "Filippo Elia Giovanni Romussi",
      "Emma Bartoletti"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. OSTETRICIA",
    "type": "Ordinari",
    "count": "4",
    "candidates": [
      "Chiara Feliziani",
      "Chiara Catanzaro",
      "Linda Brugè",
      "Giulia Romano"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. EDUCAZIONE PROFESSIONALE",
    "type": "Ordinari",
    "count": "2",
    "candidates": [
      "Edoardo Maria Leoni",
      "Rebecca Rocchetti"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. FISIOTERAPIA ANCONA",
    "type": "Ordinari",
    "count": "1",
    "candidates": [
      "Sara Tonelli"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. LOGOPEDIA ANCONA",
    "type": "Ordinari",
    "count": "5",
    "candidates": [
      "Arianna Casoli",
      "Anna Mariotti",
      "Elisa Gianfelici",
      "Benedetta Micci",
      "Chiara Marinozzi"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. DIETISTICA",
    "type": "Ordinari",
    "count": "3",
    "candidates": [
      "Noemi Strappato",
      "Matilde Galvan",
      "Federico Galli"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. IGIENE DENTALE",
    "type": "Ordinari",
    "count": "2",
    "candidates": [
      "Margherita Cimarelli",
      "Alberto Scocco"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. TECNICHE DI LABORATORIO BIOMEDICO",
    "type": "Ordinari",
    "count": "3",
    "candidates": [
      "Francesca Cordone",
      "Margherita Marini",
      "Matteo Sgrò"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. TECNICHE DELLA PREVENZIONE NELL'AMBIENTE E NEI LUOGHI DI LAVORO",
    "type": "Ordinari",
    "count": "1",
    "candidates": [
      "Gianluigi Carlo Scaramuzzi"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. INFERMIERISTICA - ANCONA",
    "type": "Ordinari",
    "count": "8",
    "candidates": [
      "Daniele Minnetti",
      "Carolina Martizzi",
      "Agnese Lombardi",
      "Gaia Bruschi",
      "Riccardo Arena",
      "Leonardo Mancinelli",
      "Yira Cesarina Castillo",
      "Benita Chiamaka Agu"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. INFERMIERISTICA - ASCOLI PICENO",
    "type": "Ordinari",
    "count": "1",
    "candidates": [
      "Silvana Di Nunzio"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. INFERMIERISTICA - MACERATA",
    "type": "Ordinari",
    "count": "3",
    "candidates": [
      "Matteo Lambertucci",
      "Carola Cota",
      "Luigi Fratini"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. INFERMIERISTICA - FERMO",
    "type": "Ordinari",
    "count": "3",
    "candidates": [
      "Manuel Rogante",
      "loana Cezara Ciocinitu",
      "Alessandro Striano"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. INFERMIERISTICA - PESARO",
    "type": "Ordinari",
    "count": "3",
    "candidates": [
      "Ilaria Migliaccio",
      "Daniel Gamba",
      "Penelope Pezzolesi"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. SCIENZE RIABILITATIVE DELLE PROFESSIONI SANITARIE",
    "type": "Ordinari",
    "count": "6",
    "candidates": [
      "Elena Casadei",
      "Giulia Mazza",
      "Chiara Abbatelli",
      "Valeria Chiappa",
      "Matteo Gaspari",
      "Nicla Di Donna"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. FISIOTERAPIA ASCOLI",
    "type": "Ordinari",
    "count": "1",
    "candidates": [
      "Riccardo Grezzani"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. LOGOPEDIA FERMO",
    "type": "Ordinari",
    "count": "3",
    "candidates": [
      "Martina Musa",
      "Laura Margiotta",
      "Angelica Lucia Aiello"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. MEDICINE AND SURGERY",
    "type": "Ordinari",
    "count": "17",
    "candidates": [
      "Gouzay Ozverir",
      "Greta Marconi",
      "Eftychia Leonidou",
      "Daniel Parente",
      "Mayar Bezzai",
      "Advait Nair",
      "Chiara Morganti",
      "Gregoria Christofi",
      "Jennifer Margarete Theresia Matienzo Baldeon",
      "Ipek Demiryurek",
      "Elifnaz Genc",
      "Mehmet Meric Horoz",
      "Francielle Kauane Da Silva Da Fonseca",
      "Kaur Jaskeert XXX",
      "Aakash Solomon Malik",
      "Jay Pinkal Jogi",
      "Kamal Rajkumar Singh"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. DATA SCIENCE FOR ECONOMICS, BUSINESS AND FINANCE",
    "type": "Ordinari",
    "count": "4",
    "candidates": [
      "Leonardo Ragni",
      "Matheus Soares Campos",
      "Mayet Biruktawit Molla detta Bruke",
      "Ben Nouba Nacef"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. SUSTAINABILITY MANAGEMENT AND CIRCULAR ECONOMY",
    "type": "Ordinari",
    "count": "3",
    "candidates": [
      "Aurora Ballarini",
      "Samira Trebovic",
      "Valeria Sicignano"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. SCIENZE MOTORIE PER LA SALUTE E L'INVECCHIAMENTO ATTIVO",
    "type": "Ordinari",
    "count": "2",
    "candidates": [
      "Chiara Papirii",
      "Edoardo Roncaglia"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. TECNICHE DI RADIOLOGIA MEDICA, PER IMMAGINI E RADIOTERAPIA - ANCONA",
    "type": "Ordinari",
    "count": "2",
    "candidates": [
      "Annalisa Spadoni",
      "Stefano Vagnoni"
    ],
    "is_cs": false
  },
  {
    "organ": "CONSIGLI UNIFICATI E CONSIGLI DI CORSO DI STUDIO (C.U.C.S E C.C.S.)",
    "sub_organ": "C.C.S. TECNICHE DI FISIOPATOLOGIA CARDIOCIRCOLATORIA E PERFUSIONE CARDIOVASCOLARE",
    "type": "Ordinari",
    "count": "2",
    "candidates": [
      "Elisa Yang",
      "Elisa Fagotti"
    ],
    "is_cs": false
  }
];

// Sub-component for candidate list item
function CandidateItem({ name, num, type }: { name: string; num: number; type?: string }) {
  return (
    <div className={styles.candidateItem}>
      <span className={styles.candidateNum}>{num}.</span>
      <span className={styles.candidateName}>
        {name}
        {type && type !== "Ordinari" && type !== "Dipartimento" && (
          <span className={`${styles.badge} ${styles['badge' + type]}`}>{type}</span>
        )}
      </span>
    </div>
  );
}

export default function CandidatiPage() {
  const organs = Array.from(new Set(DATA.map(d => d.organ)));

  return (
    <>
      <div className={styles.hero}>
        <div className={`container`}>
          <span className="section-tag section-tag-white">Elezioni 12-13-14 Maggio 2025</span>
          <h1 style={{ color: 'var(--white)', marginTop: '1rem' }}>
            I nostri candidati
          </h1>
          <p style={{ color: 'rgba(255,255,255,0.85)', marginTop: '0.75rem', fontSize: '1.1rem', maxWidth: '600px' }}>
            L&apos;elenco completo di tutte le persone che si candidano con Gulliver per rappresentare lɜ studenti.
          </p>
        </div>
      </div>

      <section className="section">
        <div className="container">
          {organs.map(organ => (
            <div key={organ} className={styles.organSection}>
              <h2 className={styles.organTitle}>{organ}</h2>

              {DATA.filter(d => d.organ === organ).map((sub, idx) => (
                <div key={idx} className={`${styles.subOrganSection} ${sub.is_cs ? styles.csHighlight : ""}`}>
                  <div className={styles.subOrganHeader}>
                    <h3>{sub.sub_organ || sub.organ}</h3>
                    <span className={styles.subOrganCount}>{sub.count} Candidati</span>
                  </div>

                  <div className={styles.candidateList}>
                    {sub.candidates.map((name, cIdx) => (
                      <CandidateItem
                        key={cIdx}
                        name={name}
                        num={cIdx + 1}
                        type={sub.type}
                      />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          ))}

          <div style={{ textAlign: "center", marginTop: "4rem" }}>
            <Link href="/elezioni-studentesche" className="btn btn-outline" id="candidati-back">
              ← Torna alle elezioni
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
